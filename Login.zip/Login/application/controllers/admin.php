<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {

    public function __construct()
    {
        parent:: __construct();  
        is_logged_in();
    }
    

    public function index() {
        
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
      
    }


    public function role() {
        
        $data['title'] = 'Role';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['role'] = $this->db->get('user_role')->result_array();
        
        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/role', $data);
        $this->load->view('templates/footer');
      
    }


    public function roleaccess($role_id) {
    $data['title'] = 'Role Access';
    $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

    // Validasi apakah role_id sesuai dengan data yang dimiliki
    $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();
    if (!$data['role']) {
        // Handle jika role_id tidak valid, bisa redirect atau tampilkan pesan kesalahan
        redirect('error_page'); // Ganti 'error_page' dengan halaman yang sesuai
    }

    // Pertimbangkan apakah ID 1 adalah ID yang sesuai dengan kondisi ini
    $this->db->where('id !=', 1);
    $data['menu'] = $this->db->get('user_menu')->result_array();

    $this->load->view('templates/header', $data);
    $this->load->view('templates/sidebar', $data);
    $this->load->view('templates/topbar', $data);
    $this->load->view('admin/role-access', $data);
    $this->load->view('templates/footer');
}



    public function changeAccess(){
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');
    
        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];
    
        // Perbaikan: Menggunakan where() untuk menentukan kondisi
        $result = $this->db->get_where('user_access_menu', $data);
    
        if($result->num_rows() < 1) {
            // Perbaikan: Menggunakan insert_batch() agar dapat menyertakan multiple rows
            $this->db->insert('user_access_menu', $data);
        } else {
            // Perbaikan: Menggunakan delete() untuk menghapus data sesuai kondisi
            $this->db->delete('user_access_menu', $data);
        }
        
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
        Access changed!</div>');
    }
    
}
